import pygame
import sys
import random

from player import Player
from explosion import Explosion


BACKGROUND_COLOR = (107, 142, 35)

font = None
game_win = False
player = None
ene_blocks = []
bombs = []
explosions = []
power_ups = []
current_time = 0
progress = 0

GRID_BASE = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
             [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
             [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
             [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]]


def game_init(surface, scale):

    global font
    font = pygame.font.SysFont('Bebas', scale)

    # global enemy_list
    global ene_blocks
    global player

    # enemy_list = []
    ene_blocks = []
    global explosions
    global bombs
    global power_ups
    bombs.clear()
    explosions.clear()
    power_ups.clear()

    player = Player()


    player.load_animations(scale)
    ene_blocks.append(player)
   

    floor_img = pygame.image.load('images/terrain/floor.png')
    floor_img = pygame.transform.scale(floor_img, (scale, scale))

    dl_img = pygame.image.load('images/terrain/deadline.png')
    dl_img = pygame.transform.scale(dl_img, (scale, scale))

    block_img = pygame.image.load('images/terrain/block.png')
    block_img = pygame.transform.scale(block_img, (scale, scale))

    block1_img = pygame.image.load('images/terrain/block1.png')
    block1_img = pygame.transform.scale(block1_img, (scale, scale))

    box1_img = pygame.image.load('images/terrain/box1.png')
    box1_img = pygame.transform.scale(box1_img, (scale, scale))

    box2_img = pygame.image.load('images/terrain/box2.png')
    box2_img = pygame.transform.scale(box2_img, (scale, scale))

    box3_img = pygame.image.load('images/terrain/box3.png')
    box3_img = pygame.transform.scale(box3_img, (scale, scale))

    box4_img = pygame.image.load('images/terrain/box4.png')
    box4_img = pygame.transform.scale(box4_img, (scale, scale))
    
    box5_img = pygame.image.load('images/terrain/box5.png')
    box5_img = pygame.transform.scale(box5_img, (scale, scale))

    bomb1_img = pygame.image.load('images/bomb/1.png')
    bomb1_img = pygame.transform.scale(bomb1_img, (scale, scale))

    bomb2_img = pygame.image.load('images/bomb/2.png')
    bomb2_img = pygame.transform.scale(bomb2_img, (scale, scale))

    bomb3_img = pygame.image.load('images/bomb/3.png')
    bomb3_img = pygame.transform.scale(bomb3_img, (scale, scale))

    explosion1_img = pygame.image.load('images/explosion/1.png')
    explosion1_img = pygame.transform.scale(explosion1_img, (scale, scale))

    explosion2_img = pygame.image.load('images/explosion/2.png')
    explosion2_img = pygame.transform.scale(explosion2_img, (scale, scale))

    explosion3_img = pygame.image.load('images/explosion/3.png')
    explosion3_img = pygame.transform.scale(explosion3_img, (scale, scale))

    terrain_images = [floor_img, block_img, box1_img, box2_img, box3_img, box4_img, box5_img, floor_img, dl_img, block1_img]
    bomb_images = [bomb1_img, bomb2_img, bomb3_img]
    explosion_images = [explosion1_img, explosion2_img, explosion3_img]

    border_img = pygame.image.load('images/others/border.png')
    border_img = pygame.transform.scale(border_img, (2.5 * scale, 0.95 * scale))

    clock_img = pygame.image.load('images/others/clock.png')
    clock_img = pygame.transform.scale(clock_img, (scale, scale))

    power_up_bomb_img = pygame.image.load('images/power_up/bomb.png')
    power_up_bomb_img = pygame.transform.scale(power_up_bomb_img, (scale, scale))

    power_up_fire_img = pygame.image.load('images/power_up/fire.png')
    power_up_fire_img = pygame.transform.scale(power_up_fire_img, (scale, scale))

    power_up_book_img = pygame.image.load('images/power_up/book.png')
    power_up_book_img = pygame.transform.scale(power_up_book_img, (scale, scale))

    power_ups_images = [power_up_bomb_img, power_up_fire_img, power_up_book_img]

    main(surface, scale, terrain_images, bomb_images, explosion_images, power_ups_images, clock_img, border_img)


def draw(s, grid, tile_size, game_ended, terrain_images, bomb_images, explosion_images, power_ups_images, clock_img, border_img):
    s.fill(BACKGROUND_COLOR)

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            s.blit(terrain_images[0], (i * tile_size, j * tile_size, tile_size, tile_size))

    bg_img = pygame.image.load('images/others/bg.png')
    bg_img = pygame.transform.scale(bg_img, (bg_img.get_width() / bg_img.get_height() * 6 * tile_size, 6 * tile_size))

    s.blit(bg_img, (1.75 * tile_size, 4 * tile_size))

    bg_img = pygame.image.load('images/terrain/floor1.png')
    bg_img = pygame.transform.scale(bg_img, (tile_size, tile_size))

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if i == 11 and j == 11:
                s.blit(terrain_images[8], (i * tile_size, j * tile_size, tile_size, tile_size))
                continue
            if i == 0 or j == 0 or i == 12 or j == 12:
                s.blit(terrain_images[9], (i * tile_size, j * tile_size, tile_size, tile_size))
                continue

            # s.blit(bg_img, (i * tile_size, j * tile_size, tile_size, tile_size))
            if grid[i][j] != 0 and grid[i][j] != 7:
                s.blit(terrain_images[grid[i][j]], (i * tile_size, j * tile_size, tile_size, tile_size))


    for pu in power_ups:
        s.blit(power_ups_images[pu.type], (pu.pos_x * tile_size, pu.pos_y * tile_size, tile_size, tile_size))

    for x in bombs:
        s.blit(bomb_images[x.frame], (x.pos_x * tile_size, x.pos_y * tile_size, tile_size, tile_size))

    for y in explosions:
        for x in y.sectors:
            s.blit(explosion_images[y.frame], (x[0] * tile_size, x[1] * tile_size, tile_size, tile_size))
    if player.life:
        s.blit(player.animation[player.direction][player.frame],
               (player.pos_x * (tile_size / 4), player.pos_y * (tile_size / 4), tile_size, tile_size))
        

    loading_bar_x = (11 - 0.3) * tile_size 
    loading_bar_y = 12 * tile_size  
    pygame.draw.rect(s, (0, 255, 0), (loading_bar_x, loading_bar_y, progress, 15))
    
    
    time_text = font.render("{}:{}{}".format(int(current_time)//60, int(current_time)%60//10, int(current_time)%60%10), True, (255, 255, 255))

    if game_win:
        gray_overlay = pygame.Surface((13 * tile_size, 13 * tile_size), pygame.SRCALPHA)
        gray_overlay.fill((0, 0, 0, 128))
        s.blit(gray_overlay, (0, 0))

        fontt = pygame.font.Font(None, 72)
        text = fontt.render("Complete The Task", True, (255, 255, 0))
        text_shadow = fontt.render("Complete The Task", True, (255, 0, 0, 70))

        
        # Tạo bức hình với chữ màu vàng và viền đỏ
        text_rect = text.get_rect(center=(13 * tile_size // 2, 13 * tile_size // 2))
        shadow_rect = text_shadow.get_rect(center=(13 * tile_size // 2 + 5, 13 * tile_size // 2 + 5))
        time_text = pygame.transform.scale(time_text, (1.3 * tile_size, 0.9 * tile_size))

        
        s.blit(text_shadow, shadow_rect.topleft)
        s.blit(text, text_rect.topleft)
        s.blit(clock_img, (5.2 * tile_size, 7.2 * tile_size))
        s.blit(time_text, (6.3 * tile_size, 7.3 * tile_size))

        if  current_time <= 90:
            text = fontt.render("GPA A+: Full Scholarship", True, (245, 2, 5))
            text = pygame.transform.scale(text, (text.get_width() / text.get_height() * 0.68 * tile_size, 0.68 * tile_size))
            text_rect = text.get_rect(center=(13 * tile_size // 2, 8.8 * tile_size ))
            s.blit(text, text_rect.topleft)
        elif current_time <= 120:
            text = fontt.render("GPA A: A half of Scholarship", True, (245, 2, 5))
            text = pygame.transform.scale(text, (text.get_width() / text.get_height() * 0.68 * tile_size, 0.68 * tile_size))
            text_rect = text.get_rect(center=(13 * tile_size // 2, 8.8 * tile_size ))
            s.blit(text, text_rect.topleft)



            
    else :
        time_text = pygame.transform.scale(time_text, (0.7 * tile_size, 0.5 * tile_size))
        time_rect = time_text.get_rect(center=( 1.58 * (border_img.get_width() // 2), 1.15 * border_img.get_height() // 2 ))
        s.blit(border_img, (0.6 * tile_size, 0))
        s.blit(clock_img, (0.4 * tile_size, 0))
        s.blit(time_text, time_rect)
        

    if game_ended:

        gray_overlay = pygame.Surface((13 * tile_size, 13 * tile_size), pygame.SRCALPHA)
        gray_overlay.fill((0, 0, 0, 128))
        s.blit(gray_overlay, (0, 0))

        fontt = pygame.font.Font(None, 72)
        text = fontt.render("Game Over", True, (255, 0, 0))
        text_shadow = fontt.render("Game Over", True, (255, 255, 0, 178))
        tf = font.render("Press ESC to go back to menu", False, (255, 255, 255))
        tf = pygame.transform.scale(tf, (tf.get_width()/tf.get_height() * 0.5 * tile_size, 0.5 * tile_size))

        
        # Tạo bức hình với chữ màu vàng và viền đỏ
        text_rect = text.get_rect(center=(13 * tile_size // 2, 13 * tile_size // 2))
        shadow_rect = text_shadow.get_rect(center=(13 * tile_size // 2 + 3.5, 13 * tile_size // 2 + 3.5))
        
        s.blit(tf, (3 * tile_size, 7 * tile_size))
        s.blit(text_shadow, shadow_rect.topleft)
        s.blit(text, text_rect.topleft)

    pygame.display.update()


def generate_map(grid):
    for i in range(1, len(grid) - 1):
        for j in range(1, len(grid[i]) - 1):
            if grid[i][j] != 0:
                continue
            elif (i < 3 or i > len(grid) - 4) and (j < 3 or j > len(grid[i]) - 4):
                continue
            if random.randint(0, 9) < 7:
                grid[i][j] = random.randint(2, 6)

    return


def main(s, tile_size, terrain_images, bomb_images, explosion_images, power_ups_images, clock_img, border_img):

    grid = [row[:] for row in GRID_BASE]
    generate_map(grid)
    # power_ups.append(PowerUp(1, 2, PowerUpType.BOMB))
    # power_ups.append(PowerUp(2, 1, PowerUpType.FIRE))
    clock = pygame.time.Clock()
    global current_time 
    global progress
    global game_win

    running = True
    game_ended = False
    loading = False
    game_win = False
    current_time = 0
    end_time = 0


    while running:
        dt = clock.tick(15)

        if not game_ended and not game_win:
            keys = pygame.key.get_pressed()
            temp = player.direction
            movement = False
            if keys[pygame.K_DOWN]:
                temp = 0
                player.move(0, 1, grid, ene_blocks, power_ups)
                movement = True
            elif keys[pygame.K_RIGHT]:
                temp = 1
                player.move(1, 0, grid, ene_blocks, power_ups)
                movement = True
            elif keys[pygame.K_UP]:
                temp = 2
                player.move(0, -1, grid, ene_blocks, power_ups)
                movement = True
            elif keys[pygame.K_LEFT]:
                temp = 3
                player.move(-1, 0, grid, ene_blocks, power_ups)
                movement = True
            if temp != player.direction:
                player.frame = 0
                player.direction = temp
            if movement:
                if player.frame == 2:
                    player.frame = 0
                else:
                    player.frame += 1

        if (not game_ended and not game_win):
            current_time += dt / 1000.0
       
        draw(s, grid, tile_size, game_ended, terrain_images, bomb_images, explosion_images, power_ups_images, clock_img, border_img)

        if not game_ended:
            game_ended = check_end_game()

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                sys.exit(0)
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_SPACE:
                    if  round(player.pos_x/4) == 10 and round(player.pos_y/4) == 11:
                        loading = True
                        continue
                    
                    if  round(player.pos_x/4) == 11 and round(player.pos_y/4) == 10:
                        loading = True
                        continue
                    
                    if player.bomb_limit <= 0 or not player.life or game_win:
                        continue

                    temp_bomb = player.plant_bomb(grid)
                    bombs.append(temp_bomb)
                    grid[temp_bomb.pos_x][temp_bomb.pos_y] = 7
                    player.bomb_limit -= 1
                elif e.key == pygame.K_ESCAPE:
                    running = False
            elif e.type == pygame.KEYUP  and e.key == pygame.K_SPACE and not game_win:
                loading = False

        if player.bomb_limit == 0:
            if player.solve:
                end_time += dt/1000.0
            if end_time > 5.5:
                player.checkdl(grid, power_ups)
        else:
            end_time = 0
            
        update_bombs(grid, dt)

        if loading == True:
        # Cập nhật thanh loading
            if not game_win:
                progress += 75/(dt * max(player.time_solve, 2) / 5)

        # Nếu thanh loading đạt đến chiều rộng tối đa, hoàn thành loading và reset lại progress
            if progress > 75:
                game_win = True
        else:
            progress = 0

    explosions.clear()
    ene_blocks.clear()
    power_ups.clear()


def update_bombs(grid, dt):
    for b in bombs:
        b.update(dt)
        if b.time < 1:
            # b.bomber.bomb_limit += 1
            grid[b.pos_x][b.pos_y] = 0
            exp_temp = Explosion(b.pos_x, b.pos_y, b.range)
            exp_temp.explode(grid, bombs, b, power_ups)
            exp_temp.clear_sectors(grid, random, power_ups)
            explosions.append(exp_temp)
    
    player.check_death(explosions)
    for e in explosions:
        e.update(dt)
        if e.time < 1:
            explosions.remove(e)


def check_end_game():
    if (not player.life) or (player.bomb_limit == 0 and (not player.solve)):
        return True

    return False
