
class PowerUp:

    def __init__(self, x, y, power_type):
        self.pos_x = x
        self.pos_y = y
        self.type = power_type
